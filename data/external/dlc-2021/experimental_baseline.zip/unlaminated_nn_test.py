import os, sys
import tensorflow as tf 
from tensorflow.keras.preprocessing.image import ImageDataGenerator 
from tensorflow.keras import layers 
from tensorflow.keras import Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.layers import Dense, Flatten, GlobalAveragePooling2D, Dropout, Conv2D, MaxPooling2D
from tensorflow.keras.applications import ResNet50
from keras.models import model_from_json

if __name__ == "__main__":
    exp_bl_dir = sys.argv[1]
    test_dir = os.path.join(exp_bl_dir, "unlaminated_nn_test")

    test_datagen = ImageDataGenerator(rescale = 1./255.)
    test_data = test_datagen.flow_from_directory(test_dir, batch_size = 256, class_mode = 'categorical', target_size = (76, 76))
    gpu_devices = tf.config.experimental.list_physical_devices('GPU')
    for device in gpu_devices:
        tf.config.experimental.set_memory_growth(device, True)

    model_json = open(os.path.join(exp_bl_dir, "unlaminated_nn_model.json") , 'r')
    loaded_model_json = model_json.read()
    model = model_from_json(loaded_model_json)
    model_json.close()
    model.load_weights(os.path.join(exp_bl_dir, "unlaminated_nn_weights.h5"))
    model.compile(optimizer = tf.keras.optimizers.Adam(learning_rate=1e-3), loss = 'binary_crossentropy', metrics = [
                  tf.keras.metrics.Recall(class_id=1), tf.keras.metrics.Precision(class_id=1),
                  tf.keras.metrics.BinaryAccuracy()])
    result = model.evaluate(test_datagen)