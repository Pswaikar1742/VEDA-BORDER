import os, sys
import tensorflow as tf 
from tensorflow.keras.preprocessing.image import ImageDataGenerator 
from tensorflow.keras import layers 
from tensorflow.keras import Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.layers import Dense, Flatten, GlobalAveragePooling2D, Dropout, Conv2D, MaxPooling2D
from tensorflow.keras.applications import ResNet50
from keras.models import model_from_json

if __name__ == "__main__":
    exp_bl_dir = sys.argv[1]
    train_dir = os.path.join(exp_bl_dir, "screen_nn_train")

    train_datagen = ImageDataGenerator(rescale = 1./255.)
    train_data = train_datagen.flow_from_directory(train_dir, batch_size = 256, class_mode = 'categorical', target_size = (224, 224))
    gpu_devices = tf.config.experimental.list_physical_devices('GPU')
    for device in gpu_devices:
        tf.config.experimental.set_memory_growth(device, True)

    base_model = Sequential()
    base_model.add(ResNet50(include_top=False, weights='imagenet', pooling='max'))
    for layer in base_model.layers:
      layer.trainable = False

    base_model.add(Dense(2, activation='softmax'))
    base_model.compile(optimizer = tf.keras.optimizers.Adam(learning_rate=1e-3), loss = 'binary_crossentropy', metrics = [
                      tf.keras.metrics.Recall(class_id=1), tf.keras.metrics.Precision(class_id=1),
                      tf.keras.metrics.BinaryAccuracy()])
    base_model.summary()
    resnet_nn = base_model.fit(train_data, steps_per_epoch = 100, epochs = 40)
    model_architecture = base_model.to_json()
    with open(os.path.join(exp_bl_dir, "screen_nn_model.json"), "w") as model_json:
        model_json.write(model_architecture)
    base_model.save_weights(os.path.join(exp_bl_dir,"screen_nn_weights.h"))