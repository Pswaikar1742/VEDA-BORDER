import os, sys
import tensorflow as tf 
from tensorflow.keras.preprocessing.image import ImageDataGenerator 
from tensorflow.keras import layers 
from tensorflow.keras import Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.layers import Dense, Flatten, GlobalAveragePooling2D, Dropout, Conv2D, MaxPooling2D
from tensorflow.keras.applications import ResNet50
from keras.models import model_from_json

if __name__ == "__main__":
    exp_bl_dir = sys.argv[1]
    train_dir = os.path.join(exp_bl_dir, "unlaminated_nn_train")
    val_dir = os.path.join(exp_bl_dir, "unlaminated_nn_test")

    train_datagen = ImageDataGenerator(rescale = 1./255., brightness_range=[0.9, 1.1])
    val_datagen = ImageDataGenerator(rescale = 1./255.)

    train_data = train_datagen.flow_from_directory(train_dir, batch_size = 256, class_mode = 'categorical', target_size = (76, 76), color_mode = 'grayscale')
    val_data = val_datagen.flow_from_directory(val_dir, batch_size = 256, class_mode = 'categorical', target_size = (76, 76), color_mode = 'grayscale')

    gpu_devices = tf.config.experimental.list_physical_devices('GPU')
    for device in gpu_devices:
        tf.config.experimental.set_memory_growth(device, True)

    callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=4)

    base_model = Sequential()

    base_model.add(Conv2D(8, kernel_size = (3, 3), activation = "relu", input_shape=(76, 76, 1)))
    base_model.add(Conv2D(16, kernel_size=(3, 3), activation="relu"))
    base_model.add(MaxPooling2D(pool_size=(2, 2)))
    base_model.add(Conv2D(16, kernel_size=(3, 3), activation="relu"))
    base_model.add(Conv2D(24, kernel_size = (3, 3), strides = (2, 2),  activation ="relu"))
    base_model.add(Conv2D(32, kernel_size = (2, 2), strides = (1,1), activation = "relu"))
    base_model.add(MaxPooling2D(pool_size=(2,2)))
    base_model.add(Conv2D(32, kernel_size = (2, 2), activation = 'relu'))
    base_model.add(Conv2D(12, kernel_size=(2, 2), activation="relu"))
    base_model.add(Flatten())
    base_model.add(Dense(2, activation='softmax', kernel_regularizer=tf.keras.regularizers.l1(0.01),
                                  activity_regularizer=tf.keras.regularizers.l2(0.01) ))
    base_model.compile(optimizer = tf.keras.optimizers.Adam(learning_rate=1e-3), loss = 'binary_crossentropy', metrics = [
                  tf.keras.metrics.Recall(class_id=1), tf.keras.metrics.Precision(class_id=1),
                  tf.keras.metrics.BinaryAccuracy()])
    base_model.summary()
    nn = base_model.fit(train_data, steps_per_epoch = 250, epochs = 30, callbacks=[callback])
    model_architecture = base_model.to_json()
    with open(os.path.join(exp_bl_dir, "unlaminated_nn_model.json"), "w") as model_json:
        model_json.write(model_architecture)
    base_model.save_weights(os.path.join(exp_bl_dir,"unlaminated_nn_weights.h5"))