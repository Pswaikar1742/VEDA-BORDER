import os, sys, shutil
import ujson, json
import cv2
import numpy as np
from joblib import delayed, Parallel
from tqdm import tqdm
import multiprocessing
import uuid
from PIL import Image

size = (224, 224)

round_val = lambda x: round(x, 4)
round_func = np.vectorize(round_val)

def extract_markup(img_path, dataset):
  #try:
  x, y, mrkp = None, None, None
  img_path = img_path.rstrip('\n')
  filename = img_path.split('/')[-1]
  if dataset == "midv2020":
    tmp = "/" + filename
    markup_path = img_path.replace(tmp, '')
    markup_path = markup_path.replace('images', 'annotations')
    img_num = filename.split('jpg')[-1]
    markup_path = markup_path.rstrip(img_num)
    markup_path += ".json"
    f = open(markup_path)
    markup_dict = ujson.loads(f.read())
    meta_data = markup_dict['_via_img_metadata']
    img_key = "none"
    for key in meta_data:
      if key.startswith(filename):
        img_key = key
    x = meta_data[img_key]['regions'][1]['shape_attributes']['all_points_x']
    y = meta_data[img_key]['regions'][1]['shape_attributes']['all_points_y']
    mrkp = [(x[i], y[i]) for i in range(4)]
    return mrkp

  elif dataset == "midv500":
    markup_path = img_path.replace('images', 'ground_truth')
    markup_path = markup_path.replace('.tif', '.json')
    f = open(markup_path)
    markup_dict = ujson.loads(f.read())
    mrkp = markup_dict['quad']
    return mrkp
  # except:
  #   #print(markup_path)
  #   pass  

def retrieve_patches(paths, i):
  try:
    dataset = 'midv2020'
    if paths[0].find('midv500') != -1:
      dataset = 'midv500'
    if paths[0].find('.jpg') == -1 and paths[0].find('.tif') == -1:
      pass
    rect = extract_markup(paths[0], dataset)
    tl = rect[0]
    tr = rect[1]
    br = rect[2]
    bl = rect[3]

    w_a = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    w_b = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    w_max = max(int(w_a), int(w_b))

    h_a = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    h_b = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    h_max = max(int(h_a), int(h_b))

    ordered_pts = (tl, tr, br, bl)
    ordered_pts = np.array(ordered_pts, dtype = 'float32')
    dst = np.array([
      [0, 0],
      [w_max - 1, 0],
      [w_max - 1, h_max - 1],
      [0, h_max - 1]], dtype = 'float32')

    transform = cv2.getPerspectiveTransform(ordered_pts, dst)
    img_path = paths[0].rstrip('\n')
    image = cv2.imread(img_path)
    warped = cv2.warpPerspective(image, transform, (w_max, h_max))
    scaled = cv2.resize(warped, size)
    img = Image.fromarray(scaled)
    img.save(os.path.join(paths[1], str(i) + '.jpg'))
  except:
    pass    


if __name__ == "__main__" :
  exp_bl_dir = sys.argv[1]  
  tr_dir = os.path.join(exp_bl_dir, "unlaminated_nn_train")
  positive_train = []
  negative_train = []
  if not os.path.exists(tr_dir):
    os.mkdir(tr_dir)
  neg_tr_dir = os.path.join(tr_dir, "0")  
  pos_tr_dir = os.path.join(tr_dir, "1")
  if not os.path.exists(neg_tr_dir):
    os.mkdir(neg_tr_dir)
  else:
    shutil.rmtree(neg_tr_dir)
    os.mkdir(neg_tr_dir)

  if not os.path.exists(pos_tr_dir):
    os.mkdir(pos_tr_dir)
  else:
    shutil.rmtree(pos_tr_dir)
    os.mkdir(pos_tr_dir)

  with open(os.path.join(exp_bl_dir, 'unlaminated_positive_train.lst'), 'r') as f1:
    for line in f1:
      img_path = str(line).rstrip('\r')
      if line.startswith('midv2020'):
        img_path = line.replace('midv2020/', 'midv2020/images/')
      if len(img_path ) > 3:  
        positive_train.append( (os.path.join(exp_bl_dir, img_path), pos_tr_dir) )

  with open(os.path.join(exp_bl_dir, 'unlaminated_negative_train.lst'), 'r') as f2:
    for line in f2:
      img_path = str(line).rstrip('\r')
      if line.startswith('midv2020'):
        img_path = line.replace('midv2020/', 'midv2020/images/')
      if len(img_path) > 3:  
        negative_train.append( (os.path.join(exp_bl_dir, img_path), neg_tr_dir) )

  n_workers = multiprocessing.cpu_count() - 1
  positive = Parallel(n_jobs=n_workers)(delayed(retrieve_patches)(positive_train[i], i) for i in tqdm(range(len(positive_train))))
  negative = Parallel(n_jobs=n_workers)(delayed(retrieve_patches)(negative_train[i], i) for i in tqdm(range(len(negative_train))))    
