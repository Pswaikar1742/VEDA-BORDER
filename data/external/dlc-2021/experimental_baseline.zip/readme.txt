DLC-2021 Experimental baselines.

- Unpack clips.tar into experimental_baselines/dlc folder.

- Download MIDV-2020 (ftp://smartengines.com/midv-2020/), than unpack clips.tar into experimental_baselines/midv2020 folder.

- Download MIDV-500 (ftp://smartengines.com/midv-500/), than unpack all zip files from 'dataset' folder into experimental_baselines/midv500 folder.

--------------------------------------------------------------------------------
1. Screen presence detector.

- Create training set using screen_train.py (python3 screen_train.py <path_to_experimental_baselines_folder>).

- Run screen_nn_train.py (python3 screen_nn_train.py <path_to_experimental_baselines_folder>). Your model will be saved to experimental_baselines/screen_nn_model.json, your 
model's weights will be saved to experimental_baselines/screen_nn_weights.h .

- Create testing set using screen_test.py (python3 screen_test.py <path_to_experimental_baselines_folder>).

- Evaluate your model on testing set using screen_nn_test.py. (python3 screen_nn_test.py <path_to_experimental_baselines_folder>).
--------------------------------------------------------------------------------
2. Unlaminated document detector.

- Create training set using unlaminated_train.py (python3 unlaminated_train.py <path_to_experimental_baselines_folder>).

- Run unlaminated_nn_train.py (python3 unlaminated_nn_train.py <path_to_experimental_baselines_folder>). Your model will be saved to experimental_baselines/unlaminated_nn_model.json, your model's weights will be saved to experimental_baselines/unlaminated_nn_weights.h .

- Create testing set using unlaminated_test.py (python3 unlaminated_test.py <path_to_experimental_baselines_folder>).

- Evaluate your model on testing set using unlaminated_nn_test.py. (python3 unlaminated_nn_test.py <path_to_experimental_baselines_folder>).
--------------------------------------------------------------------------------
3. Gray copy detector.

- Create training set using gray_copy_training.py (python3 gray_copy_train.py <path_to_experimental_baselines_folder>).

- Create testing set using gray_copy_test.py (python3 gray_copy_test.py <path_to_experimental_baselines_folder>).
--------------------------------------------------------------------------------
4. Dummy Classifier (for all types of detector)

- Create training and testing sets for screen / unluminated / graycopy detector.

- Run dummy_classifier.py (python3 dummy_classifier.py <name_of_detector> <path_to_experimental_baselines_folder>)
name_of_detector: "screen" / "unlaminated" / "graycopy"
--------------------------------------------------------------------------------
