from PIL import Image
import numpy as np
import os, sys, shutil
from joblib import Parallel, delayed
import multiprocessing
from tqdm import tqdm

size = 224

def retrieve_patches(params, i):
  image = Image.open(params[0])
  cropped_image = image.crop((params[1], params[2], params[1] + size, params[2] + size))
  out_path = params[3].replace(".jpg", "_" + str(i) + ".jpg")
  cropped_image.save(out_path)

if __name__ == "__main__":
  exp_bl_dir = sys.argv[1]
  test_dir = os.path.join(exp_bl_dir, "screen_nn_test")
  positive_test = []
  negative_test = []
  if not os.path.exists(test_dir):
    os.mkdir(test_dir)
  neg_test_dir = os.path.join(test_dir, "0")  
  pos_test_dir = os.path.join(test_dir, "1")
  if not os.path.exists(neg_test_dir):
    os.mkdir(neg_test_dir)
  else:
    shutil.rmtree(neg_test_dir)
    os.mkdir(neg_test_dir)

  if not os.path.exists(pos_test_dir):
    os.mkdir(pos_test_dir)
  else:
    shutil.rmtree(pos_test_dir)
    os.mkdir(pos_test_dir)

  with open(os.path.join(exp_bl_dir, 'screen_positive_test.lst'), 'r') as f1:
    for line in f1:
      img_params = line.split()
      img_path = os.path.join(exp_bl_dir, "dlc/clips/images", img_params[0])
      l_p = int(img_params[1])
      t_p = int(img_params[2])
      cur_img = Image.open(img_path)
      pref = img_path.split("/")[-3] + "_" + img_path.split("/")[-2] + "_" + img_path.split("/")[-1].replace(".jpg", "_" + str(l_p) + ".jpg")
      positive_test.append((img_path, l_p, t_p, os.path.join(pos_test_dir, pref)))
  with open(os.path.join(exp_bl_dir, 'screen_negative_test.lst'), 'r') as f2:
    for line in f2:
      img_params = line.split()
      img_path = os.path.join(exp_bl_dir, "dlc/clips/images", img_params[0])
      l_p = int(img_params[1])
      t_p = int(img_params[2])
      cur_img = Image.open(img_path)
      pref = img_path.split("/")[-3] + "_" + img_path.split("/")[-2] + "_" + img_path.split("/")[-1].replace(".jpg", "_" + str(l_p) + ".jpg")
      negative_test.append((img_path, l_p, t_p, os.path.join(neg_test_dir, pref)))

  n_workers = multiprocessing.cpu_count() - 1

  positive = Parallel(n_jobs=n_workers)(delayed(retrieve_patches)(positive_test[i], i) for i in tqdm(range(len(positive_test))))
  negative = Parallel(n_jobs=n_workers)(delayed(retrieve_patches)(negative_test[i], i) for i in tqdm(range(len(negative_test))))